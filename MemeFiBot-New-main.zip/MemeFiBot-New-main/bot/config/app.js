const app = {
  version: "1.0.0",
  apiUrl: "https://api-gw-tg.memefi.club/graphql",
  peer: "memefi_coin_bot",
  bot: "memefi_coin_bot",
  webviewUrl: "https://tg-app.memefi.club",
  origin: "https://tg-app.memefi.club/",
  referer: "https://tg-app.memefi.club/",
};

module.exports = app;
